import pandas as pd

names = ['raman','jatin','divya']
gender = ['male','male','female']
sal = [1111,3222,3333]

tb = pd.DataFrame({'name':names,'gender':gender,'sal':sal})
print(tb)

#print table size / shape
print(tb.shape) # row , col

#show list of columns 
print(tb.columns)

#print given naem
print(tb['name'])

#group by
print(tb.groupby('gender').size())
print(tb.groupby('gender').max())
print(tb.groupby('gender').min())
print(tb.groupby('gender').sum())




## describe : show the stats for numeric column
# count
# sum
# mean
# std dev
#min
#max
#25%
#50%
#75%

print(tb.describe())



