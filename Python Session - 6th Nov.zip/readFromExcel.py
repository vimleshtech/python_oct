import pandas as a
import matplotlib.pyplot as p

data = a.read_csv(r'C:\Users\kumaranil\Desktop\employee.csv')

print(data)
print(data.shape)
print(data.columns)

#show top 2 rows 
print(data.head(2))

#show from last
print(data.tail(3))

#sorting / order by

print( data.sort_values('NAME',ascending=True) )

d = data.sort_values('NAME',ascending=True)

x = d.sort_values('SALARY',ascending=False)
print(x)


data.plot(kind='bar', subplots=True, layout=(2,2), sharex=False, sharey=False)
p.show()



