a  = input('enter string : ')

def getCount(words,f):
        counter = 0
        i =0
        while  i<len(words):
            if words[i] ==f:
                counter+=1
            i+=1

        return counter

while True:
    op = input('press 1 to search char 2 for word and 3 for string search and 4 for exit')

    if op =='1':        
        f = input('enter char to search ')
        if len(f)>1:
            print('invalid input, you can ener single char')
            continue 
        words = list(a)        
        coungter = getCount(words,f)
        print('count of given char is : ',counter)
    elif op =='2':        
        f = input('enter word to search ')
        words = a.split(' ')
        counter = getCount(words,f)
        print('count of given word is : ',counter)
    elif op =='3':
        f = input('enter word to search ')
        counter = len(a) - len( a.replace(f,''))
        print('count of given string ',counter/len(f))


    elif op=='4':
        break
    else:
        print('wrong choice, please select again')