#create new file if file is not exist
f = open(r'mydata.txt','w')

i =1 
while i<5:
    d =input('enter data ')
    f.write(d)
    f.write('\n')
    i+=1




f.close()
