
r = open(r'C:\Users\vkumar15\Documents\django\DataAnalytics\Oct30\Python Session - 30th Oct.txt','r')

#read all content 
#print(r.read())


#read first line or line by line
#print(r.readline())
#print(r.readline())

#read all lines and convert to list 
data = r.readlines()
print(data[4]) #read given rows 

#print no. of lines in file
print(len(data))

##wap to get count of words 
wc =0
pwc = 0
for line in data:
    col = line.split(' ')
    wc+=len(col)
    for w in col:
        if w =='read':
            pwc+=1


print('coun of word in file : ',wc)
print('particualr word count ',pwc)

#close the instance 
r.close()
