def hello():
     print('hello function')
     print('end of function')


def add():
     a =1
     b =3
     c=a+b
     print(c)



#call to function
hello()

add()
add()

