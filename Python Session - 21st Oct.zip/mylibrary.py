def add():
     print('add')

def sub():
     print('sub')

def mul():
     print('mul')



     
