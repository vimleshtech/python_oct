# no argument no return 
def wel():
     print('welcome to function world')

#no argument with return 
def getData():
     a = input('enter data :')
     b = input('enter data :')
     return int(a),int(b)

#argument with no return 
def add(a,b):
     c =a+b
     print(c)
#argument with return 
def sub(a,b):

     c = a-b
     return c


#with default argument
def add1(a,b,c=0,d=0): # here c,d variable declared with default value i.e. 0
     x = a+b+c+d
     print(x)
     

#dynamic argument
def addNum(*a):
     print(a)
     
##call to function
wel()

x,y = getData()
print(x+y)
print(x-y)


add(11,22)
add(x,y)

a = sub(11,23)
print(a)

add1(11,2)
add1(11,2,3)
add1(11,2,4,5)


addNum(11,2,2,2,3,3,2,2,2,2,23,4,4,4)
addNum(33,323,2)


     
     

