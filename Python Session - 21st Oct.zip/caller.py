#import module
#example : 1

'''
import mylibrary

mylibrary.add()
mylibrary.sub()
'''


#example : 2
'''
import mylibrary as m  #create alias of module 
m.add()
'''

#example 3
from mylibrary import * #add,sub
add()
sub()




