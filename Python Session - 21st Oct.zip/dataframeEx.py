import pandas as pd


data = pd.read_csv(r'C:\Users\vkumar15\Desktop\Rohit Sessions - Sep 3rd\emp.csv')

#print(data)
print(data.columns)
print(data.head(2)) #return top rows
print(data.tail(2))  # return buttom rows

#read particular column
print(data['name'])

#read particular row

print(data[1:4]) # from 2nd to 4th row (1 to 3)


d = data.values

print(d[0:2,0:3])  # 0:2  row index,  0:3 col index
print(d)

##describe
print(data.describe())


###group by :
print(data.groupby('gender').size())
print(data.groupby('country').size())
print(data.groupby('country').sum())
print(data.groupby('country').max())
print(data.groupby('country').min())




      




