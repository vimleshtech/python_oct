#declare variable 
a =11
b =44

#expression 
c =a+b

#output 
print('sum of two numbers  ',c)



###
a = int( input('enter data :'))
b =int( input('enter data :'))

print(type(a),end='')
print(type(b),end='\t')

c =a+ b 
print(c)



