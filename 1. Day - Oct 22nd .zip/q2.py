s1=int(input('input marks of student1:'))
s2=int(input('input marks of student2:'))
s3=int(input('input marks of student3:'))
s4=int(input('input marks of student4:'))
s5=int(input('input marks of student5:'))
div=0

div=(s1+s2+s3+s4+s5)/5
print(div)

if div>=60:     
     print('first')
elif div>50:
     print('second')
elif div>40:
     print('third')
else:
     print('fail')
