s= int ( input('salary of the person:'))

hra=0
da=0

if s<10000:
     hra=s*.10
     da=s*.5
else:
     hra=s*.10
     da=s*.5
     
total=s+hra+da
print('total salary is:',total)


