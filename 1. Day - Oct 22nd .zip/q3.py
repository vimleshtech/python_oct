units= int (input ('enter the number of units:'))
amount=0
if units<100:
     amount=units*.40+50
     
elif units<300:
     amount = 40+(units-100)*.50+50
     
else:
     amount = 140+(units-300)*.60+50
     
     


print('the total amount is:',amount)
