amt = int(input('enter sale amount :' ))

tax = 0
#if condition 
if amt>1000:
     tax = amt *.10
     

total = amt+tax
print('total amt is :',total)

##if else

#if condition 
if amt>1000:
     tax = amt *.10     
else:
     tax = amt *.05

     
total = amt+tax
print('total amt is :',total)


     
