
#with default argument  , default value of c,d is 0 
def add(a,b,c=0,d=0):
    m =a+b+c+d
    print(m)



#- dynamic argument  / anonyms function 
def mul(*a):
    print(a)
    i =0
    out = 1
    while i<len(a):
        out *= a[i]
        i += 1  # i=i+1

    print(out)



add(1,2)
add(11,2,333)
add(1,24,5555,44)

mul(11,22,33,4,34,3,3,23,2,3,3,34,4,3,3,3)
