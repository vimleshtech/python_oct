#no argument , and no return 
def welcome():
    print('welcome to function world...')
    print('there are following functions 1. add 2. sub 3. mul ')

#no argument with return 
def getData():
    a =int( input('enter data '))
    b =  int(input('enter data '))

    return a,b

#argument with no return 
def add(a,b):
    c = a+b
    print(c)


#argument with return 
def sub(a,b):
    c =a-b
    return c 

#invoke or call to function 
welcome()

x,y = getData()
print(x+y)


x,y = getData()
print(x-y)

add(x,y)
add(111,34433344)


o  = sub(x,y)
print(o)