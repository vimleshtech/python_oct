'''
import libraryEx
libraryEx.add(22,3)

o = libraryEx.mul(11,23)
print(o)

'''

from libraryEx import add,mul 

add(11,3)


#or 
import libraryEx as l 
l.add(11,3)


