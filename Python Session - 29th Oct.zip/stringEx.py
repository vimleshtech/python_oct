
name = input('enter name : ')

print('you have entered ',name)

#convert to upper case
u = name.upper()
print(u)

#convert to lower case 
u = name.lower()
print(u)

#get count of chars
l = len(name)
print(l)

#convert to proper case 
u = name.title()
print(u)


#replace 
u = name.replace('a','xy')  # rxymxyn sinhxy
print(u)

### remove leading space 
l = len(name)
print(l)

u= name.strip()
l = len(u)
print(l)


#if " abcd sjshfs  ".strip() =='abcd'

#list : convert string to list : char by char 
d = list(u)
print(d)



### split  : break string by given seperator 
data = name.split(" ")  # this is python code 
#["this",  "is" ,  "python",  "code"]
print(data)



#count of is ?
pwc = 0

i =0  # 
while i< len(data):

    if data[i] =='is':
        pwc+=1

    print(data[i])
    i=i+1


#print word count
print('word count ',len(data))

print('count of is ',pwc)





