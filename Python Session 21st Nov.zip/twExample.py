import tweepy #access to tweet app

from textblob import TextBlob #text/tweet parse # keys and tokens from the Twitter Dev Console


consumer_key = 'TL7RyLnfilYH6xaoAlS0XFDCg'
consumer_secret = 'u5uBn4P62PMIxT4uwUVTl1Ycx4rsfByFs6jl2e4SQ9zDjPIzCO'
access_token = '919434545924935681-2woCDEXuXQdhJewDaCRBqHBYmi5SFDN'
access_token_secret = 'T29jqUm6rZqsRYO7AGc47GlgYTaAaN5OtJD0DATo1uBjh'

auth = tweepy.OAuthHandler(consumer_key, consumer_secret)
# set access token and secret
auth.set_access_token(access_token, access_token_secret)

# create tweepy API object to fetch tweets
api = tweepy.API(auth)

print('login pass')


leaders =['Narendra Modi','Rahul Gandhi','Sonia Gandhi']

for l in leaders:
     out =api.search(q=l,count=20)
     #print(out)
     for r in out:
          try:
               print(r.text)
          except:
               print('error')
               





          
     




