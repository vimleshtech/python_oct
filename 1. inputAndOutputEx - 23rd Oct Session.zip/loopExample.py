i =1 # init
while i<=10:  # condition
     print(i)

     i =i+1 # incrementer
     
     

#print in same line
i=1
while i<10:
     print(i,end='')
     i =i+1
     

print()
#print in reverse order
i =10
while i>0:
     print(i)
     i=i-1
     
