print('hi',end=',')
print('raman')

##read data from user
a =int(input('enter data :'))
b =int(input('enter data :'))


print(type(a))
print(type(b))


c =a+b
print(c)
