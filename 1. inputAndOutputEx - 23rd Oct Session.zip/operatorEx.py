a=21
b=44
c                   =              44

total=a+b+c
print('total score =',total)

avg=total/3
print(avg)


a=2
b=a*3
print(b)


b=a**3
print(b)
