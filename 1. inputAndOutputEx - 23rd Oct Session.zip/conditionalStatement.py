##if condition
sale = int(input('enter sale amt :'))

tax =0

if sale>1000:
     tax = sale*.10

total=sale+tax
print('total amount is :',total)

 
###if else condition
tax = 0
if sale>1000:
     tax = sale*.10
else:
     tax = sale*.05

total=sale+tax
print('total amount is :',total)


##ladder if elif elif ... else

a = int(input('enter data :'))
b = int(input('enter data :'))
c = int(input('enter data :'))
#find largest value
if a>b and a>c:
     print('a is greater ')
elif b>a and b>c:
     print('b is greater' )
else :
     print('c is greater ')
     

##nested if else: if inside if 
if a>b:
     if a>c:
          print('a is greater')
     else:
          print('c is greater')
else:
     if b>c:
          print('b is greater')
     else:
          print('c is greatr')

          

     



     





















     
