from tkinter import *

o = Tk()

o.mainloop()
