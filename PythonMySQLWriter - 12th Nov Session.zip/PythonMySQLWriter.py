import mysql.connector

#establish connection from python to mysql server
con = mysql.connector.connect(host="localhost",user="root",password="root",database="hrms")

#connect the cursor to sql connection , here cursor can run/execute/fire the sql command
cur = con.cursor()

uid = input('enter uid :')
name = input('enter name :')
s = input('enter sal :')

#execute or run the command
# "++"
cur.execute("insert into emp(uid,name,sal) values("+uid+",'"+name+"',"+s+")")

con.commit()
