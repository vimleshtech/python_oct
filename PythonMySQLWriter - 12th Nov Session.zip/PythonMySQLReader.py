import mysql.connector

#establish connection from python to mysql server
con = mysql.connector.connect(host="localhost",user="root",password="root",database="hrms")

#connect the cursor to sql connection , here cursor can run/execute/fire the sql command
cur = con.cursor()

#execute or run the command
cur.execute("select * from emp;")

#read data from cur to list 
res = cur.fetchall()

print (res)
