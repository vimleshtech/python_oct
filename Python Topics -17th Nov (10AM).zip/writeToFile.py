#w-> create new file if not exit, overwrite the data if exist

o = open(r'C:\Users\techvision\Desktop\Raman\Salesforce Topics - 17th Nov.txt','a')
o.write('skjsjgsjhsfhgs')
o.write('\n')
o.close()





