o = open(r'C:\Users\techvision\Desktop\Raman\Salesforce Topics - 17th Nov.txt','r')
#read all content
#print(o.read())

#read first line
#print(o.readline())

#read all content and convert to list
d = o.readlines()
#print(d)

#get row count
print('row count ',len(d))

#read dat line by line
#get word count form file
wc =0
for line in d:
    #print(line)
    w = line.split(' ')
    wc = wc+len(w)

print('word  count ',wc)

    
    


