words= {'a':'alpha','b':'beat',1:'one',101:[11,'nitin']}
print(type(words))

#print all value
print(words)

#print value by key
print(words['b'])

#search value by key
s = input('enter key to search :')
print(words[s])

#add new key in existing dict
words['s']='same'

print(words)



