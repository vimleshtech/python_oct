#input() : default value is int
st = raw_input('enter dat : ') #stroing

#upper
print(st.upper())

#lower
print(st.lower())

#title
print(st.title())

#list
l = list(st)
print(l)

#len
c = len(st)
print(c)


#strip
ss = st.strip()
print(len(ss))

#replace
nw = st.replace('is','are')
print(nw)

#split
w = st.split(' ')
print(w)
print(len(w))  #word count






                




      




