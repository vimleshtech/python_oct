import mysql.connector

#establish the cnnection 
con = mysql.connector.connect(host='localhost',user='root',password='root',database='hrms')

#link the sql cursor with con 
cur = con.cursor() #execute sql command

i = input('enter id :')
n = input('enter name :')

#cur.execute("insert into emp(id,name) values(i,'n')")
#"++"
cur.execute("insert into emp(id,name) values("+i+",'"+n+"')")
con.commit()

print('data is saved to db')


     
