n = int(input('enter data:'))
d = int(input('enter data:'))

try:
     if d<0:
       er  = ValueError('divisor cannot be less than 0')
       raise er
     
     o =n/d
     print(o)
     #print(x)

except ZeroDivisionError as e:
     print(e)
except ValueError as v:
     print(v)
except:
     print('invalid data')

finally:
     print('end of code')
     
o =n+d
print(o)


