import mysql.connector

#establish the cnnection 
con = mysql.connector.connect(host='localhost',user='root',password='root',database='hrms')

#link the sql cursor with con 
cur = con.cursor() #execute sql command

cur.execute('select * from emp')

out = cur.fetchall()

for r in out:
     print(r)
     
