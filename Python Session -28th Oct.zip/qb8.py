'''
name = input("name")
salary= input(int(salary))
'''

name = input('enter name :')
salary = int(input('enter salary :'))
print ('name and salary',name ,salary)

#calculatig hra and da
if salary>1000:
    hra= salary*.10
    ''' elif :
        salary>=10000
    hra= salary*.05
    '''
else:
    da= salary*.05
print('new salary is',salary)