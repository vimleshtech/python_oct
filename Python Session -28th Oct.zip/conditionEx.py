
sales=int(input('enter sales amount '))

tax =0
#if condition without else 
if sales>1000:
    tax = sales*.18

total = sales+tax 
print('total amount ',total)


#if else 
tax =0
if sales>1000:
    tax = sales*.18

else:
    tax = sales*.05

total = sales+tax 
print('total amount ',total)


### print grade based on given marks in 4 subjects
sid = int(input('enter sid '))
sname = input('enter name ')
hs = int(input('enter mark in hindi '))
es = int(input('enter mark in eng. '))
cs = int(input('enter mark in comp '))
ms = int(input('enter mark in matsh. '))


total = hs+es+cs+ms 
avg=total/4

print('sid is ',sid)
print('name is ',sname)
print('total score is ',total)
print('average score is ',avg)

if avg>=80:
    print("Gade is A")
elif avg>=60:
    print('Grade is B')
elif avg>=40:
    print('Grade is C')
else:
    print('Grade is D')

