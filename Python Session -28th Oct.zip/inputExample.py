
#take input from user 
name = input('enter name :')
salary = input('enter salary :')

#print /show result
print('name is ',name )
print('salary is ',salary)
print(type(salary),end='\t')


##convert string to integer 
salary = int(salary)
print(type(salary))

##compute hra, and da of given salary
hra = salary*.40
da= salary*.20

total=salary+hra+da
print('basic sal =',salary)
print('hra = ',hra)
print('da = ',da)
print('total monthly salary ',total)





