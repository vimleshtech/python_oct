
name= input('name')
m1=int(input('marks m1marks '))
m2=int(input('marks m2,marks '))
m3=int(input('marks m3,marks '))
m4=int(input('marks m4,marks '))
m5=int(input('marks m5,marks '))

total= m1+m2+m3+m4+m5
print("total marks is ", total)
avg=total/5
print("avg marks is ", avg)

if avg>=60:
    print("division")
elif avg<50:
     print('line pe pass')

else:
    print('fail')