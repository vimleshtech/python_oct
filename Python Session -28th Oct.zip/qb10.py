elecid= input('enter ur electricity ca id')
unit= int(input('enter the units read fromthe meter'))

if unit>=100:
    bill=unit*40+50
elif unit<=200:
    bill=unit*50+50
else:
    print("take loan")

print('bill is',bill)