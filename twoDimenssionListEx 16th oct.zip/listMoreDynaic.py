data =[]

while True:

    op = input('press 1 for add 2 for show 3 for delete 4 for exit ')

    if op =='1':
        d = input('enter data :')
        data.append(d)

    elif op =='2':
        print(data)

    elif op =='3':
        v = input('enter value to remove :')

        if v in data:
            data.remove(v)
        else:
            print('given value is not found ')
            

    elif op == '4':
        break

    else:
        print('invalid choice, pls select again ')

        
