# wap to remove row by employee id
# wap to count of male and female row

data =[]

while True:

    op = input('press 1 for add 2 for show 3 for delete 4 for exit ')

    if op =='1':
        eid = input('enter eid  :')
        ename = input('enter name  :')
        esal = input('enter sal  :')
        gender = input('enter gender  :')
        
        data.append( [eid,ename,esal,gender] )

    elif op =='2':
        
        print(data)

    elif op =='3':
        v = input('enter value to remove :')

        if v in data:
            data.remove(v)
        else:
            print('given value is not found ')
            

    elif op == '4':
        break

    else:
        print('invalid choice, pls select again ')

        
