data = []  # declare empty list

for i in range(1,10):
    d = input('enter data  :')
    data.append(d)


print(data)


#find the value and it's frequency
v = input('enter data to find :')
counter = 0

for d in data:
    if d == v:
        counter+=1  # counter = counter+1
        
print(counter)        

#or
counter =0
for i in range(0,len(data)):
    if data[i] == v:
        counter = counter+1
print(counter)        
        

