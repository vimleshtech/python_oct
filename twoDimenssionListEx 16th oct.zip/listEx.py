data = [1,2,2,3,4]

#pritn all values
print(data)

#print 1st element
print(data[0])


#slicer 
print(data[0:2])  #print 1st, 2nd element
print(data[:2])  #print 1st, 2nd element

###print last element
print(data[-1])   # negative index : read from right

#functions / list operation
#there are following inbuilt function

data.append(1000)  # add new value after last index
print(data)

#add value dynamically
n = int(input('eter data : '))  #default data type is str (when data will come from console or from file)
data.append(n)
print(data)

          
#pop : remove from last
data.pop()
print(data)


##insert : add new value at given position
data.insert(1,2000)
print(data)



#remove  : delete value from list
#data.remove(2000)
#print(data)

#search value by index then remove
data.remove(data[2])

##sort: arrange data in acending order
#ascending is default
data.sort()
print(data)

#print in descending order
#using slicer
print(data[:-1])
print(data[::-1])  # :  -> read left to right , ::  -> read right to left 


##function
print(max(data))    # highest value 
print(min(data))    # lowest value
print(sum(data))    # total of all numbers
print(len(data))  # count of values/element






















