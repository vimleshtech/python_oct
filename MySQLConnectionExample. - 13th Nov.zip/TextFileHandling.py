o = open(r'C:\Users\vkumar15\Desktop\Python\data\emp.txt','r')
#r : ingnore the unicode 
#print(o.read())  # read all content from file

#print(o.readline()) # read first line
#print(o.readline())

x = o.readlines()
#print(res)

for r in  x:  # read line by line 
     print(r)
     

o.close()#close the instance of file

############## write data to the file
#new file will be created if file doesn't exit 
x = open(r'C:\Users\vkumar15\Desktop\Python\data\out.txt','a')
x.write('test \n') # \n : new line
x.write('bye')
x.close()










