import pandas

s = "https://archive.ics.uci.edu/ml/machine-learning-databases/iris/iris.data"

cols = ['c1','c2','c3','c4','c5']

out = pandas.read_csv(s, names=cols)

print(out)
