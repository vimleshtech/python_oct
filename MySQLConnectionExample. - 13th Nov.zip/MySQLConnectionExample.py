import mysql.connector

con= mysql.connector.connect(host="localhost",user="root",password="root",database="hrms")

cur = con.cursor()
cur.execute("select * From emp")

r = cur.fetchall()
#print(r)
for d in r:
     print(d[0])
     


