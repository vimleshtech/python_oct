import pandas
out = pandas.read_csv(r'C:\Users\vkumar15\Desktop\Python\data\emp.csv')

print(out)

#
print(out.columns)
print(out.shape)
print(out.head(2))  # show top given no of rows
print(out.tail(3)) # show buttom given no of rows

#show stats
print(out.describe())



####
o = out.head(2)

o.to_csv(r'C:\Users\vkumar15\Desktop\Python\data\emp2.csv')



