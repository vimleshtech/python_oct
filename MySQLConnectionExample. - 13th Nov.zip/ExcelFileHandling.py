import xlrd
import pandas as pd

src = r"C:\Users\vkumar15\Desktop\Python\data\Service Assurance - Raw Data.xlsx"
wb = xlrd.open_workbook(src)

sh = wb.sheet_by_index(0)  # first worksheet
#wb.sheet_by_name('SA')

cc = sh.ncols
rc = sh.nrows

print(cc)
print(rc)


uclient = []
n = []
#print(sh.cell_value(9, 0) )
for r  in range(0,rc):
     #for c in range(0,cc):
     #     print(sh.cell_value(r, c) )

     #print(sh.cell_value(r, 1) )
     #if sh.cell_value(r, 1) not in uclient:
     #     uclient.append(sh.cell_value(r, 1))
     uclient.append(sh.cell_value(r, 1))
     n.append(sh.cell_value(r, 2))
     
     
o = pd.DataFrame({'cname':uclient,'number':n})
print(o)




          
          


