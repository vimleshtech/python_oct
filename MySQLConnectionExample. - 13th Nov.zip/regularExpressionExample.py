'''
re : reugular expression
     pattern , text/string/data

pattern:

[A-Z]
[a-z]
[A-Za-z]
/w    : char
/W    : non-char
[0-9]
/d   : digit 
/D   : non digit
.    : any char
*    : any no of times
()   : group


match() : is method/ function 
'''

import re
data = input('enter data :')

o = re.match('(.*) are (.*)',data)
if o:
     print('are is exist ')
else:
     print('not match')



           








