while True:
     try:          
          n = int(input('enter no :'))
          d = int(input('enter no :'))          
          o = n/d          
          print(o)
          break
     except:
          print('plz try again')


          
