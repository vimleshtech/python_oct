def rec(n):
     if n>1:
          print(n)
          rec(n-1)
     else:
          print(n)
          
          

#call / invoke to function 
rec(5)

###
def readFile(src):
     c = src.split(".")
     if len(c)<1:
          dirs = os.listdir(src)
          for p in dirs:
               readFile(p)
               
     else:
          o = open(src,'r')
          for row in o.readlines():
               print(row)
               
          
          

#call / invoke to function
d=["c:/","d:/"]
for x in d:
     paths = os.listdir(x)
     for p in paths:
          readFile(p)


