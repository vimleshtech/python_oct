import pandas as pd


def getKmeans(path):
     out = pd.read_csv(path)
     #print(out)
     #print(out.columns)

     #convert df to list 
     li =  out.values
     #print(li)

     total = 0
     for row in li:
          total += row[9]

     print(total)
     kmeans = []
     for row in li:
          kmean = row[9]/total
          kmeans.append(kmean)

     #print(kmeans)
     return kmeans
     

def getCluster(kmeans):
     low = min(kmeans)
     hig = max(kmeans)
     ran = hig - low
     mean = ran/2
     res=[]
     for i in range(0,2):
          row=[]
          for k in kmeans:
               if k >= low and k<mean:
                    row.append(k)


          res.append(row)
          low = mean
          mean = mean + mean
          

     print(res)
          
          
     
          
src =r'C:\Users\vkumar15\Desktop\Python\test.csv'
kmeans = getKmeans(src)
getCluster(kmeans)








