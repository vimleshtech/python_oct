data = [1,2,3,3,4,222,333,444,3323,22,22344,333]

#wap to get count of all even no. from list

counter=0

for i in range(0,len(data)):
     if data[i] % 2 ==0:
          counter=counter+1


print('count of even no is : ',counter)         
               
#or

counter=0
for d in data:
     if d % 2 ==0:
          counter=counter+1

print('count of even no is : ',counter)

#### data
data = [[1,2,3],[4,5,6],[7,8,9,55]]
print(data)
print(data[1])

for r in data:
     print(r)     

##
for r in data: #2D -> Row
     for c in r: #row -> col
          print(c)
          
          



