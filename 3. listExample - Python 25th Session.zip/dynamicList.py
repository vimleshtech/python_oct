sales = [] #declare empty list

for i in range(1,10):
     d = int(input('enter data :'))
     sales.append(d)

print(sales)


data=[]
while True:

     ch = input('enter 1 for add 2 for show 3 for remove 4 for exit ')

     if ch =='1':
          d = int(input('enter data :'))
          data.append(d)
     elif ch=='2':
          print(data)
     elif ch =='3':
          d = int(input('enter data :'))
          if d in data:
                 data.remove(d)
          else:
               print('data is not found ')
     elif ch =='4':
          break
     else:
          print('invalid input , pls try again..')
          



          
     
               
     
