i=1   #init
while i<10:  # condition
     j =1  # init
     while j<5: # condition

          print(j,end='')
          
          j=j+1 # incrementer     


     i=i+1 # increment
     print()
     
     
