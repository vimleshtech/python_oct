data =(111,444,555,3)
print(len(data))
print(max(data))
print(min(data))
print(sum(data))

#data[1]=100
a=[]
for d in data:
     a.append(d)

print(a)
a[1]=111
print(a)




