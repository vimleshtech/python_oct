data = [1111,222,333,444,5555]

print(data)
print(data[0])
print(data[0:4])
print(max(data))
print(min(data))
print(len(data))
print(sum(data))


d =int(input('enter data to add :'))

data.append(d)
print(data)

data.pop()

data.sort()
print(data)


