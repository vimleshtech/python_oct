d ={'a':'alpha','b':'beta',1:'one'}

print(d)
print(d['b'])

##add
d['c']='ceta'

print(d)

###
emp={101:[101,'raman','male',11111],102:[102,'jatin','male',4344] }

print(emp[101])



##
s ={'dove','lux','dove',333}
print(s)






