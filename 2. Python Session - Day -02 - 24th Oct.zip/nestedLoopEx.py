for r in range(1,5):  # no. of rows / height 
	for c in range(1,4): # no. of cols / width 
		print(c,end='')
	print()




##
for r in range(1,5):  # no. of rows / height 
	for c in range(1,4): # no. of cols / width 
		print('*',end='')
	print()


##
'''
1
12
123
1234
*      r =1   c = 1 to r+1 (2) 
**     r = 2  c = 1 to r+1 2+1 = 3  (1,3) 1 2  
***
****
'''
for r in range(1,10):  # no. of rows / height 
	for c in range(1,r+1): # no. of cols / width 
		print('*',end='')
	print()

'''
****
***
**
*
'''
for r in range(1,5):  # no. of rows / height 
	for c in range(r,5): # no. of cols / width 
		print('*',end='')
	print()









	









	
	
	


