n = int(input('enter number : '))

a=1

for i in range(1,n+1):
        
    if a% 2== 0:
            print('-',a,end='')
    else:
            print(a,end='')

    if i<n:
        print(',',end='')
              

    a =a+3
    
                  
        
