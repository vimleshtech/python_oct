n = int(input('enter number : '))


for i in range(1,n+1):

    print('(',end='')

    for c in range(1,i+1):
        
        print(c,end='+')


    print(')+',end='')
