'''
i =1
while i<=10:
    print(i)
        
    i=i+1

##
for i in range(1,10):   #from 1 to less than 10 , default incrementer is 1
    print(i)
    
    
##print all odd numbers between 1 to 30
for i in range(1,30,2):
    print(i)
'''    
    

#print in reverse order
for j in range(10,0,-1):  # from 10 to greaer than 0 (till 1)
    print(j)
    
