#create class , here emp is name of the class 
class emp:
    #functions / methods 
    def newEmp(add):
        add.eid = input('enter employee id :')
        add.ename = input('enter employee name :')
        add.sal = int( input('enter basic sal :'))

    def __init__(a):
        print('object is created ..this class contains following functions \n 1. newemp 2. compute 3. disp/show')
        
        
    def compute(add):
        add.hra = add.sal * .40
        add.da = add.sal * .20
        add.msal = add.sal + add.hra+ add.da
        add.ysal = add.msal * 12

    def disp(add):
        print('...employee details ....')
        print(add.eid)
        print(add.ename)
        print(add.msal)
        print(add.ysal)


class tax_india:

    def input2(self):
        self.pan = input('enter pan no.:')
        self.amt = int(input('enter amt in (INR)  :'))

    def tax(self):
        
        if self.amt <=300000:
            self.tax = 0
        elif self.amt <=500000:
            self.tax = (self.amt-300000) * .05
        elif self.amt <=1000000:
            self.tax = 10000+ (self.amt-500000) * .20
            
        else:
            self.tax = 110000+ (self.amt-1000000) * .30
        print('Total tax in (INR) = ',self.tax)
        

class tax_us:

    def input2(self):
        self.pan = input('enter pan no.:')
        self.amt = int(input('enter amt in ($)  :'))

    def tax(self):
        
        if self.amt <=100000:
            self.tax = 0
        elif self.amt <=500000:
            self.tax = (self.amt-100000) * .10
        else:
            self.tax = (self.amt-500000) * .40
            
        print('Total tax in ($) = ',self.tax)

    def __del__(s):
        print(s,' is deleted ')

    def addNum(s,a,b): # s is address of object, and a,b are variable/argument
        c =a+b
        print(c)
        

#create object of class : emp
o = emp()  #here o is an object of class (emp)
print(o)
#o.newEmp()
#o.compute()
#o.disp()

t = tax_us()
t.input2()
t.tax()
t.addNum(111,22)

print('end of program ')

#delete object 
del t
#t.input2()

