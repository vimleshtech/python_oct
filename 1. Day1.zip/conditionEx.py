hs = int(input('enter data :'))
cs = int(input('enter data :'))
es = int(input('enter data :'))
ms = int(input('enter data :'))


total = hs+cs+es+ms
avg = total/4

print(total)
print(avg)

if avg>80:
     print('A')
elif avg>60:
     print('B')
elif avg>40:
     print('C')
else:
     print('D')

     


