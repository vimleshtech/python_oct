Number=input('please enter the number')
Square=int(Number)*int(Number)
print(Square)

Number=input('please enter the number')
Square=int(Number)*int(Number)*int(Number)
print(cube)
