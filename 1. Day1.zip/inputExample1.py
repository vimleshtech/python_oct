Rollno=input('enter roll number of student:')
name=input('enter name of student:')
m1=input('enter marks in m')
m2=input('enter the marks in b')
m3=input('enter the marks in c')
total = int(m1) + int(m2) + int(m3) #typecast/convert str to int before +
avg=total/3
print(total)
print(avg)



