Number=input('please enter the number')
cube=int(Number)*int(Number)*int(Number)
print(cube)
