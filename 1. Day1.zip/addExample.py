
print('this is test program')  # show messagne and change line 
print('hello')

###print and don't change line
print('hi',end='')
print(' Raman')

##
hs =11
es =44
cs =88

total  = hs+es+cs
avg = total/3

print(total)
print('average score is ',avg)




